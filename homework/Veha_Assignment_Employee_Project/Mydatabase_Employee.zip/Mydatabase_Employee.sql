-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.7.24 - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             10.1.0.5464
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping structure for table employee_db.main_tb
CREATE TABLE IF NOT EXISTS `main_tb` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `sex` varchar(32) NOT NULL,
  `email` varchar(150) NOT NULL,
  `addr` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

-- Dumping data for table employee_db.main_tb: 3 rows
/*!40000 ALTER TABLE `main_tb` DISABLE KEYS */;
INSERT INTO `main_tb` (`id`, `first_name`, `last_name`, `sex`, `email`, `addr`) VALUES
	(20, 'Som ', 'Veha', 'Male', 'somveha@gmail.com', 'Siem Reap'),
	(18, 'Som', 'Reaksa', 'Male', 'somreaksa@gmail.com', 'Siem Reap'),
	(19, 'Seng', 'Sourng', 'Female', 'sengsourng@gmail.com', 'Siem Reap');
/*!40000 ALTER TABLE `main_tb` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
